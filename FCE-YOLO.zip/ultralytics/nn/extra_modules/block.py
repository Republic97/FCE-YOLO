"""Feature-pyramid module used by FCE-YOLO."""

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.conv import Conv

__all__ = ("FeaturePyramidSharedConv",)


class FeaturePyramidSharedConv(nn.Module):
    """Build a feature pyramid by reusing one convolution at multiple dilation rates."""

    def __init__(self, c1, c2, dilations=(1, 3, 5)):
        super().__init__()
        hidden_channels = c1 // 2
        self.cv1 = Conv(c1, hidden_channels, 1, 1)
        self.cv2 = Conv(hidden_channels * (1 + len(dilations)), c2, 1, 1)
        self.share_conv = nn.Conv2d(hidden_channels, hidden_channels, 3, 1, 1, bias=False)
        self.dilations = tuple(dilations)

    def forward(self, x):
        features = [self.cv1(x)]
        for dilation in self.dilations:
            features.append(
                F.conv2d(
                    features[-1],
                    weight=self.share_conv.weight,
                    bias=None,
                    dilation=dilation,
                    padding=dilation,
                )
            )
        return self.cv2(torch.cat(features, 1))
