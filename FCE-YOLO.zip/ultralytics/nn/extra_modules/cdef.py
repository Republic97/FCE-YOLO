"""Cross-level Dual-branch Enhancement Fusion (CDEF) module used by FCE-YOLO."""

import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.conv import Conv, DWConv

__all__ = ("CDEF",)


class CDEFSemanticPath(nn.Module):
    """Apply channel-wise semantic guidance to the high-level feature."""

    def __init__(self, channels):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv2d(channels, channels, 1, 1, 0, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        return x * self.sigmoid(self.conv(self.pool(x)))


class CDEFBridgePath(nn.Module):
    """Transform the mid-level feature before fusion."""

    def __init__(self, channels):
        super().__init__()
        self.conv1 = Conv(channels, channels, 1, 1)
        self.conv2 = Conv(channels, channels, 3, 1)
        self.conv3 = Conv(channels, channels, 3, 1)

    def forward(self, x):
        return x * self.conv3(self.conv2(self.conv1(x)))


class CDEF(nn.Module):
    """Fuse high-level and mid-level features through two enhancement branches."""

    def __init__(self, in_channels, c_out):
        super().__init__()
        c_high, c_mid = in_channels
        self.high_align = Conv(c_high, c_out, 1, 1)
        self.mid_align = Conv(c_mid, c_out, 1, 1)
        self.high_path = CDEFSemanticPath(c_out)
        self.mid_path = CDEFBridgePath(c_out)
        self.fuse = nn.Sequential(
            Conv(c_out * 2, c_out, 1, 1),
            DWConv(c_out, c_out, 3, 1),
            Conv(c_out, c_out, 1, 1),
        )

    def forward(self, x):
        x_high, x_mid = x
        x_high = self.high_align(x_high)
        x_mid = self.mid_align(x_mid)

        target_size = x_mid.shape[2:]
        if x_high.shape[2:] != target_size:
            x_high = F.interpolate(x_high, size=target_size, mode="bilinear", align_corners=False)

        x_high = self.high_path(x_high)
        x_mid = self.mid_path(x_mid)
        return self.fuse(torch.cat((x_high, x_mid), dim=1))
