"""Custom modules required by FCE-YOLO."""

from .block import FeaturePyramidSharedConv
from .cdef import CDEF

__all__ = ("CDEF", "FeaturePyramidSharedConv")
