"""Run inference with a trained FCE-YOLO checkpoint."""

import argparse
from pathlib import Path

from ultralytics import YOLO


ROOT = Path(__file__).resolve().parent
DEFAULT_WEIGHTS = ROOT / "runs/train/FCE-YOLO_ep200/weights/best.pt"


def parse_args():
    parser = argparse.ArgumentParser(description="Run FCE-YOLO inference.")
    parser.add_argument("--source", required=True, help="Image, directory, video, or stream to process.")
    parser.add_argument("--weights", type=Path, default=DEFAULT_WEIGHTS, help="Checkpoint path.")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--device", default=None, help="Device such as 0 or cpu.")
    parser.add_argument("--project", type=Path, default=ROOT / "runs/detect")
    parser.add_argument("--name", default="predict")
    return parser.parse_args()


def main():
    args = parse_args()
    if not args.weights.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {args.weights}")

    predict_options = {
        "source": args.source,
        "imgsz": args.imgsz,
        "conf": args.conf,
        "project": str(args.project),
        "name": args.name,
        "save": True,
    }
    if args.device is not None:
        predict_options["device"] = args.device

    YOLO(str(args.weights)).predict(**predict_options)


if __name__ == "__main__":
    main()
