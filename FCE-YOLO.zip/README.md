# FCE-YOLO

FCE-YOLO is an object detector based on Ultralytics YOLO11n.

The bundled Ultralytics code is based on version 8.3.9.

## Dataset

The dataset used in the paper is not included. Prepare an external dataset in Ultralytics YOLO format and update [`data.yaml`](data.yaml) with its local paths.

## License

This project modifies Ultralytics YOLO 8.3.9 and is released under the [GNU AGPL-3.0](LICENSE).
