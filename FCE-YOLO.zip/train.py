"""Train FCE-YOLO with FeaturePyramidSharedConv, CDEF, and EMASlideLoss."""

import argparse
from pathlib import Path

from ultralytics import YOLO


ROOT = Path(__file__).resolve().parent
DEFAULT_MODEL = ROOT / "ultralytics/cfg/models/fce-yolo/fce-yolo.yaml"


def parse_args():
    parser = argparse.ArgumentParser(description="Train FCE-YOLO.")
    parser.add_argument("--model", type=Path, default=DEFAULT_MODEL, help="Model YAML path.")
    parser.add_argument("--data", type=Path, required=True, help="Path to an external dataset YAML file.")
    parser.add_argument("--weights", default=None, help="Optional pretrained weights, e.g. yolo11n.pt.")
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--batch", type=int, default=32)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--workers", type=int, default=10)
    parser.add_argument("--device", default=None, help="Device such as 0, 0,1, or cpu.")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--project", type=Path, default=ROOT / "runs/train")
    parser.add_argument("--name", default="FCE-YOLO_ep200")
    parser.add_argument("--cache", action="store_true", help="Cache dataset images.")
    return parser.parse_args()


def main():
    args = parse_args()
    if not args.model.is_file():
        raise FileNotFoundError(f"Model configuration not found: {args.model}")
    if not args.data.is_file():
        raise FileNotFoundError(f"Dataset configuration not found: {args.data}")

    model = YOLO(str(args.model))
    if args.weights:
        model.load(args.weights)

    train_options = {
        "data": str(args.data.resolve()),
        "cache": args.cache,
        "imgsz": args.imgsz,
        "epochs": args.epochs,
        "batch": args.batch,
        "close_mosaic": 20,
        "workers": args.workers,
        "optimizer": "SGD",
        "patience": 0,
        "seed": args.seed,
        "deterministic": True,
        "project": str(args.project),
        "name": args.name,
    }
    if args.device is not None:
        train_options["device"] = args.device

    model.train(**train_options)


if __name__ == "__main__":
    main()
