"""Evaluate FCE-YOLO and save metrics used in the paper."""

import argparse
from pathlib import Path

from ultralytics import YOLO
from ultralytics.utils.torch_utils import model_info


ROOT = Path(__file__).resolve().parent
DEFAULT_WEIGHTS = ROOT / "runs/train/FCE-YOLO_ep200/weights/best.pt"


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate FCE-YOLO.")
    parser.add_argument("--weights", type=Path, default=DEFAULT_WEIGHTS, help="Checkpoint path.")
    parser.add_argument("--data", type=Path, required=True, help="Path to an external dataset YAML file.")
    parser.add_argument("--split", choices=("train", "val", "test"), default="test")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=32)
    parser.add_argument("--device", default=None, help="Device such as 0 or cpu.")
    parser.add_argument("--project", type=Path, default=ROOT / "runs/test")
    parser.add_argument("--name", default="FCE-YOLO_ep200")
    return parser.parse_args()


def markdown_table(headers, rows):
    """Return a compact Markdown table."""
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    lines.extend("| " + " | ".join(str(value) for value in row) + " |" for row in rows)
    return "\n".join(lines)


def safe_fps(milliseconds):
    return 1000.0 / milliseconds if milliseconds > 0 else 0.0


def main():
    args = parse_args()
    if not args.weights.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {args.weights}")
    if not args.data.is_file():
        raise FileNotFoundError(f"Dataset configuration not found: {args.data}")

    model = YOLO(str(args.weights))
    val_options = {
        "data": str(args.data.resolve()),
        "split": args.split,
        "imgsz": args.imgsz,
        "batch": args.batch,
        "project": str(args.project),
        "name": args.name,
    }
    if args.device is not None:
        val_options["device"] = args.device
    result = model.val(**val_options)

    preprocess_ms = result.speed["preprocess"]
    inference_ms = result.speed["inference"]
    postprocess_ms = result.speed["postprocess"]
    total_ms = preprocess_ms + inference_ms + postprocess_ms
    _, parameters, _, flops = model_info(model.model, imgsz=args.imgsz)

    info_table = markdown_table(
        (
            "GFLOPs",
            "Parameters",
            "Preprocess (s/image)",
            "Inference (s/image)",
            "Postprocess (s/image)",
            "End-to-end FPS",
            "Inference FPS",
            "Weight size (MB)",
        ),
        [
            (
                f"{flops:.1f}",
                f"{parameters:,}",
                f"{preprocess_ms / 1000:.6f}",
                f"{inference_ms / 1000:.6f}",
                f"{postprocess_ms / 1000:.6f}",
                f"{safe_fps(total_ms):.2f}",
                f"{safe_fps(inference_ms):.2f}",
                f"{args.weights.stat().st_size / 1024 / 1024:.1f}",
            )
        ],
    )

    metric_rows = []
    for metric_index, class_index in enumerate(result.box.ap_class_index):
        metric_rows.append(
            (
                result.names[int(class_index)],
                f"{result.box.p[metric_index]:.4f}",
                f"{result.box.r[metric_index]:.4f}",
                f"{result.box.f1[metric_index]:.4f}",
                f"{result.box.ap50[metric_index]:.4f}",
                f"{result.box.all_ap[metric_index, 5]:.4f}",
                f"{result.box.ap[metric_index]:.4f}",
            )
        )

    mean_f1 = float(result.box.f1.mean()) if len(result.box.f1) else 0.0
    metric_rows.append(
        (
            "all",
            f"{result.results_dict['metrics/precision(B)']:.4f}",
            f"{result.results_dict['metrics/recall(B)']:.4f}",
            f"{mean_f1:.4f}",
            f"{result.results_dict['metrics/mAP50(B)']:.4f}",
            f"{result.box.map75:.4f}",
            f"{result.results_dict['metrics/mAP50-95(B)']:.4f}",
        )
    )
    metrics_table = markdown_table(
        ("Class", "Precision", "Recall", "F1", "mAP50", "mAP75", "mAP50-95"), metric_rows
    )

    report = f"# Model information\n\n{info_table}\n\n# Detection metrics\n\n{metrics_table}\n"
    report_path = Path(result.save_dir) / "paper_data.md"
    report_path.write_text(report, encoding="utf-8")
    print(report)
    print(f"Metrics saved to {report_path}")


if __name__ == "__main__":
    main()
